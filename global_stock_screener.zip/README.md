# Global Stock Screener 🌎

This Streamlit app scans global stocks (US, NSE, HKEX, LSE, TSX) for:
- ✅ FCF Yield > 5%
- ✅ Piotroski F-Score ≥ 5
- ✅ 1W Price Change > 7%
- ✅ Analyst Ratings from Zacks, StockAnalysis, WallStreetZen
- ✅ Export to CSV/Excel
- ✅ Deployable on Streamlit Cloud

## Usage
```bash
pip install -r requirements.txt
streamlit run main.py
```
